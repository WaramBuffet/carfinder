# Roadmap

- [x] Gemeinsame Fahrzeugdatenbasis für beide Ansichten sicherstellen
- [x] Toggle mit teilbaren Direktlinks und Sitzungsspeicherung umsetzen
- [x] Sachliche Ansicht „Zahlen & Fakten“ umsetzen
- [x] Editoriale Ansicht „Mit Gefühl“ weiterentwickeln
- [x] Fotoübersicht für alle Modelle mit Sprungzielen integrieren
- [x] Desktop- und iPhone-Ansichten sowie Interaktionen testen
- [x] Hersteller-Links (site) für alle 15 Fahrzeuge ergänzen – Build-/Typfehler beheben
- [x] Sortierung: Rate ohne Wert bleibt auch absteigend am Ende
- [x] Mobile Sortierung mit eigener Richtungsauswahl (auf/ab)
- [x] Direktlinks #car-SLUG wählen und scrollen bei Desktop UND Mobil beim Initialladen
- [ ] Publikationsreife final prüfen (Build-Log, Browser-Tests) – Veröffentlichung wartet auf Freigabe
